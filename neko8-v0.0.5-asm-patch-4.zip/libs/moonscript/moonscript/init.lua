do
  local _with_0 = require("libs.moonscript.moonscript.base")
  _with_0.insert_loader()
  return _with_0
end
