local hi = "hello"
local hello = "what the heckyes"
print(hi)
local umm = 'umm'
local here, another = "yeah", 'world'
local aye = "YU'M"
you('"hmmm" I said')
print(aye, you)
another = [[ hello world ]]
local hi_there = [[  hi there
]]
local well = [==[ "helo" ]==]
local hola = [===[  eat noots]===]
local mm = [[well trhere]]
local oo = ""
local x = "\\"
x = "a\\b"
x = "\\\n"
x = "\""
local a = "hello " .. tostring(hello) .. " hello"
local b = tostring(hello) .. " hello"
local c = "hello " .. tostring(5 + 1)
local d = tostring(hello(world))
local e = tostring(1) .. " " .. tostring(2) .. " " .. tostring(3)
local f = [[hello #{world} world]]
a = 'hello #{hello} hello'
b = '#{hello} hello'
c = 'hello #{hello}'
local _ = "hello"
("hello"):format(1);
("hello"):format(1, 2, 3);
("hello"):format(1, 2, 3)(1, 2, 3);
("hello"):world();
("hello"):format().hello(1, 2, 3);
("hello"):format(1, 2, 3)
something("hello"):world()
return something(("hello"):world())