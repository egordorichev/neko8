local you_cool = false
if cool then
  if you_cool then
    local _ = one
  else
    if eatdic then
      local _ = yeah
    else
      local _ = two
      _ = three
    end
  end
else
  local _ = no
end
if cool then
  local _ = no
end
if cool then
  local _ = no
else
  local _ = yes
end
if cool then
  wow(cool)
else
  noso(cool)
end
if working then
  if cool then
    if cool then
      local _ = okay
    else
      local _ = what
    end
  else
    local _ = nah
  end
end
if yeah then
  no(day)
elseif cool(me) then
  okay(ya)
else
  u(way)
end
if yeah then
  no(dad)
else
  if cool(you) then
    okay(bah)
  else
    p(way)
  end
end
if (function() end)() then
  what(ever)
end
if nil then
  flip(me)
else
  it(be, rad)
end
if things(great) then
  no(way)
elseif okay(sure) then
  what(here)
end
if things then
  no(chance)
elseif okay then
  what(now)
end
if things then
  yes(man)
elseif okay(person) then
  hi(there)
else
  hmm(sure)
end
if lets(go) then
  print("greetings")
elseif "just us" then
  print("will smith")
else
  show(5555555)
end
do
  local something = 10
  if something then
    print(something)
  else
    print("else")
  end
end
local hello
do
  local something = 10
  if something then
    hello = print(something)
  else
    hello = print("else")
  end
end
hello = 5 + (function()
  do
    local something = 10
    if something then
      return print(something)
    end
  end
end)()
local z = false
if false then
  local _ = one
else
  do
    local x = true
    if x then
      local _ = two
    else
      do
        z = true
        if z then
          local _ = three
        else
          local _ = four
        end
      end
    end
  end
end
local out
if false then
  out = one
else
  do
    local x = true
    if x then
      out = two
    else
      do
        z = true
        if z then
          out = three
        else
          out = four
        end
      end
    end
  end
end
local kzy
kzy = function()
  do
    local something = true
    if something then
      return 1
    else
      do
        local another = false
        if another then
          return 2
        end
      end
    end
  end
end
if not (true) then
  print("cool!")
end
if not (true and false) then
  print("cool!")
end
if not (false) then
  print("cool!")
end
if not (false) then
  print("cool!")
else
  print("no way!")
end
if not (nil) then
  print("hello")
else
  print("world")
end
local x
if not (true) then
  x = print("cool!")
end
if not (true and false) then
  x = print("cool!")
end
local y
if not (false) then
  y = print("cool!")
end
if not (false) then
  y = print("cool!")
else
  y = print("no way!")
end
if not (nil) then
  z = print("hello")
else
  z = print("world")
end
print((function()
  if not (true) then
    return print("cool!")
  end
end)())
print((function()
  if not (true and false) then
    return print("cool!")
  end
end)())
print((function()
  if not (false) then
    return print("cool!")
  end
end)())
print((function()
  if not (false) then
    return print("cool!")
  else
    return print("no way!")
  end
end)())
print((function()
  if not (nil) then
    return print("hello")
  else
    return print("world")
  end
end)())
if not (value) then
  print("hello")
end
local dddd
if not (value) then
  dddd = {
    1,
    2,
    3
  }
end
do
  local j = 100
  do
    j = hi()
    if not j then
      error("not j!")
    end
  end
end
local a = 12
local c, b
if something then
  a, c, b = "cool"
end
local j
if 1 then
  if 2 then
    j = 3
  end
else
  j = 6
end
local m
if 1 then
  if 2 then
    m = 3
  end
else
  m = 6
end
return nil