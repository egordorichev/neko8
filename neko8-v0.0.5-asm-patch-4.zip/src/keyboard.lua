local keyboard = {}

function keyboard.init()
	-- todo
end

function keyboard.update()

end

function keyboard.draw()

end

return keyboard


