
local neko = {}

neko.printh = true
neko.csize = true
neko.rect = true
neko.rectfill = true
neko.brect = true
neko.brectfill = true
neko.color = true
neko.cls = true
neko.circ = true
neko.circfill = true
neko.pset = true
neko.pget = true
neko.line = true
neko.print = true
neko.flip = true
neko.cursor = true
neko.cget = true
neko.scroll = true
neko.spr = true
neko.sspr = true
neko.sget = true
neko.sset = true
neko.pal = true
neko.palt = true
neko.map = true

neko.btn = true
neko.btnp = true
neko.key = true

return neko
