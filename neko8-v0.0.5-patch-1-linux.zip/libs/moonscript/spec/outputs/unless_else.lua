if a then
  if not (b) then
    return print("hi")
  elseif c then
    return print("not hi")
  end
end