local _ = {
  1,
  2
}
_ = {
  1,
  2
}
_ = {
  1,
  2
}
_ = {
  1,
  2
}
_ = {
  1,
  2
}
_ = {
  something(1, 2, 4, 5, 6),
  3,
  4,
  5
}
_ = {
  a(1, 2, 3),
  4,
  5,
  6,
  1,
  2,
  3
}
_ = {
  b(1, 2, 3, 4, 5, 6),
  1,
  2,
  3,
  1,
  2,
  3
}
_ = {
  1,
  2,
  3
}
_ = {
  c(1, 2, 3)
}
hello(1, 2, 3, 4, 1, 2, 3, 4, 4, 5)
x(1, 2, 3, 4, 5, 6)
hello(1, 2, 3, world(4, 5, 6, 5, 6, 7, 8))
hello(1, 2, 3, world(4, 5, 6, 5, 6, 7, 8), 9, 9)
_ = {
  hello(1, 2),
  3,
  4,
  5,
  6
}
local x = {
  hello(1, 2, 3, 4, 5, 6, 7),
  1,
  2,
  3,
  4
}
if hello(1, 2, 3, world, world) then
  print("hello")
end
if hello(1, 2, 3, world, world) then
  print("hello")
end
a(one, two, three)
b(one, two, three)
c(one, two, three, four)
return nil