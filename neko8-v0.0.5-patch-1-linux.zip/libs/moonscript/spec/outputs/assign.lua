local _
_ = function()
  local joop = 2302
  return function(hi)
    local d = 100
    hi = 1021
    local a, b, c
    a, b, c, d = 1, 2, 3, 4
    local hello
    hello[232], (5 + 5)[121], hello, x[99] = 100, 200, 300
    joop = 12
  end
end
local joop = 2345
local a, b
if hello then
  a, b = "hello"
else
  a, b = "nothing", "yeah"
end
if hello then
  if yeah then
    a, b = "one", "two"
  else
    a, b = "mmhh"
  end
else
  print("the other")
  a, b = "nothing", "yeah"
end