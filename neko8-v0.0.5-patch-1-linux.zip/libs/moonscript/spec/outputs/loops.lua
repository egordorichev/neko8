for x = 1, 10 do
  print("yeah")
end
for x = 1, #something do
  print("yeah")
end
for y = 100, 60, -3 do
  print("count down", y)
end
for a = 1, 10 do
  print("okay")
end
for a = 1, 10 do
  for b = 2, 43 do
    print(a, b)
  end
end
for i in iter do
  for j in yeah do
    local x = 343 + i + j
    print(i, j)
  end
end
local _list_0 = something
for _index_0 = 1, #_list_0 do
  local x = _list_0[_index_0]
  print(x)
end
for k, v in pairs(hello) do
  print(k, v)
end
for x in y,z do
  print(x)
end
for x in y,z,k do
  print(x)
end
local x
x = function()
  for x in y do
    local _ = y
  end
end
local hello = {
  1,
  2,
  3,
  4,
  5
}
do
  local _accum_0 = { }
  local _len_0 = 1
  for _index_0 = 1, #hello do
    local y = hello[_index_0]
    if y % 2 == 0 then
      _accum_0[_len_0] = y
    end
    _len_0 = _len_0 + 1
  end
  x = _accum_0
end
x = function()
  for _index_0 = 1, #hello do
    local x = hello[_index_0]
    local _ = y
  end
end
local t
do
  local _accum_0 = { }
  local _len_0 = 1
  for i = 10, 20 do
    _accum_0[_len_0] = i * 2
    _len_0 = _len_0 + 1
  end
  t = _accum_0
end
local hmm = 0
local y
do
  local _accum_0 = { }
  local _len_0 = 1
  for j = 3, 30, 8 do
    hmm = hmm + 1
    local _value_0 = j * hmm
    _accum_0[_len_0] = _value_0
    _len_0 = _len_0 + 1
  end
  y = _accum_0
end
local _
_ = function()
  for k = 10, 40 do
    _ = "okay"
  end
end
_ = function()
  return (function()
    local _accum_0 = { }
    local _len_0 = 1
    for k = 10, 40 do
      _accum_0[_len_0] = "okay"
      _len_0 = _len_0 + 1
    end
    return _accum_0
  end)()
end
while true do
  print("name")
end
while 5 + 5 do
  print("okay world")
  working(man)
end
while also do
  i(work(too))
  _ = "okay"
end
local i = 0
do
  local _accum_0 = { }
  local _len_0 = 1
  while i < 10 do
    local _value_0
    i = i + 1
    _accum_0[_len_0] = _value_0
    _len_0 = _len_0 + 1
  end
  x = _accum_0
end
do
  local _accum_0 = { }
  local _len_0 = 1
  local _list_1 = 3
  for _index_0 = 1, #_list_1 do
    local thing = _list_1[_index_0]
    local _value_0
    y = "hello"
    _accum_0[_len_0] = _value_0
    _len_0 = _len_0 + 1
  end
  x = _accum_0
end
do
  local _accum_0 = { }
  local _len_0 = 1
  for x = 1, 2 do
    local _value_0
    y = "hello"
    _accum_0[_len_0] = _value_0
    _len_0 = _len_0 + 1
  end
  x = _accum_0
end
while true do
  local _continue_0 = false
  repeat
    if false then
      _continue_0 = true
      break
    end
    print("yes")
    if true then
      break
    end
    print("no")
    _continue_0 = true
  until true
  if not _continue_0 then
    break
  end
end
for x = 1, 10 do
  local _continue_0 = false
  repeat
    if x > 3 and x < 7 then
      _continue_0 = true
      break
    end
    print(x)
    _continue_0 = true
  until true
  if not _continue_0 then
    break
  end
end
local list
do
  local _accum_0 = { }
  local _len_0 = 1
  for x = 1, 10 do
    local _continue_0 = false
    repeat
      if x > 3 and x < 7 then
        _continue_0 = true
        break
      end
      local _value_0 = x
      _accum_0[_len_0] = _value_0
      _len_0 = _len_0 + 1
      _continue_0 = true
    until true
    if not _continue_0 then
      break
    end
  end
  list = _accum_0
end
local _list_1 = {
  1,
  2,
  3,
  4,
  5,
  6
}
for _index_0 = 1, #_list_1 do
  local _continue_0 = false
  repeat
    local a = _list_1[_index_0]
    if a == 1 then
      _continue_0 = true
      break
    end
    if a == 3 then
      _continue_0 = true
      break
    end
    print(a)
    _continue_0 = true
  until true
  if not _continue_0 then
    break
  end
end
for x = 1, 10 do
  local _continue_0 = false
  repeat
    if x % 2 == 0 then
      _continue_0 = true
      break
    end
    for y = 2, 12 do
      local _continue_1 = false
      repeat
        if y % 3 == 0 then
          _continue_1 = true
          break
        end
        _continue_1 = true
      until true
      if not _continue_1 then
        break
      end
    end
    _continue_0 = true
  until true
  if not _continue_0 then
    break
  end
end
while true do
  local _continue_0 = false
  repeat
    do
      if false then
        _continue_0 = true
        break
      end
      break
    end
    _continue_0 = true
  until true
  if not _continue_0 then
    break
  end
end
while true do
  local _continue_0 = false
  repeat
    do
      if false then
        _continue_0 = true
        break
      end
      return 22
    end
    _continue_0 = true
  until true
  if not _continue_0 then
    break
  end
end
do
  local xxx = {
    1,
    2,
    3,
    4
  }
  for _index_0 = 1, #xxx do
    local thing = xxx[_index_0]
    print(thing)
  end
end